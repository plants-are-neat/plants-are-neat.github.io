var net = require('net');
var http = require('http');
var HOST = '0.0.0.0';
var PORTIN = 8080;



http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.end("Testing");
}).listen(8081);

net.createServer(function(sock) {
    //console.log('CONNECTED:',sock.remoteAddress,':',sock.remotePort);
    sock.setEncoding("utf8"); //set data encoding (either 'ascii', 'utf8', or 'base64')
    sock.on("error", function(err){
    });
    sock.on('data', function(data) {
      console.log(data);
      sock.write("Message received: Back to you")
    })

}).listen(PORTIN, HOST, function() {
    console.log("server accepting connections");
});